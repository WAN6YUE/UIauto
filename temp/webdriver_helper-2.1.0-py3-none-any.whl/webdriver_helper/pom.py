import logging
from abc import ABCMeta
from pathlib import Path
from typing import Callable, List, Optional
from warnings import warn

import parse
from selenium.common.exceptions import (
    NoAlertPresentException,
    StaleElementReferenceException,
)
from selenium.webdriver.chrome.webdriver import WebDriver
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.expected_conditions import url_changes
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait

from webdriver_helper import upload_by_drop

__all__ = [
    "BasePage",
    "AlertPage",
    "LazyElement",
    "LazyElementList",
    "LazyAlert",
    "By",
]
logger = logging.getLogger(__name__)


class PageMeta(ABCMeta):
    driver: WebDriver
    wait: WebDriverWait
    time_out: float
    poll: float
    url: str

    def __new__(cls, *args, **kwargs):
        cls = type.__new__(cls, *args, **kwargs)
        cls._check_elements = PageMeta._check_elements
        cls._wait_interactive = PageMeta._wait_interactive
        return cls

    def _check_elements(self):

        if self.url:
            current_url = self.driver.current_url
            msg = (
                f"URL in browser({current_url}) cannot match"
                f" URL pattern in POM({self.url})"
            )
            assert parse.parse(self.url, current_url), msg

        for k in dir(self):
            if k.startswith("__"):
                continue

            attr = getattr(self, k)
            if isinstance(attr, BaseLazy):
                attr = attr.from_instance(attr)
                setattr(self, k, attr)
                logger.debug(f"Element Init: {k=}, {attr=}")

                attr.update(
                    driver=self.driver,
                    time_out=self.time_out,
                    poll=self.poll,
                )

                if attr.check_on_init and not isinstance(
                    attr, LazyElementList  # LazyElementList can not check
                ):
                    logger.debug(f"check: {attr.text}")

    def _wait_interactive(self, ele: WebElement):

        self.wait.until(
            lambda _: all(
                [
                    ele.is_displayed(),
                    ele.is_enabled(),
                    ele.get_attribute("readonly") in (False, None),
                ]
            )
        )


class BaseLazy(metaclass=ABCMeta):
    driver: Optional[WebDriver] = None
    _attrs: tuple
    _page: tuple
    _origin_class: object

    def __repr__(self):
        s_attrs = ""
        for attr in self._attrs:
            if attr == "driver" or attr.startswith("obj"):
                continue
            attr = getattr(self, attr, None)
            s_attrs += f"{attr=} "

        return f"<{self.__class__.__name__} ({s_attrs})>"

    def __getattribute__(self, item: str):
        if item.startswith("__"):
            return super().__getattribute__(item)

        if item in (
            "driver",
            "update",
            "_origin_class",
            "_attrs",
            "_page",
            "_find_element",
            "from_instance",
        ):
            return super().__getattribute__(item)

        if item in self._attrs:
            return super().__getattribute__(item)

        if not hasattr(self.__class__._origin_class, item):
            raise AttributeError(
                f"The attribute does not exist :{item} in {self.__class__._origin_class}"
            )
        else:

            ele = self._find_element()
            return getattr(ele, item)

    def update(self, **kwargs):
        for k, v in kwargs.items():
            if all(
                [
                    k in self.__class__._attrs + ("driver",),
                    getattr(self, k, None) is None,
                ]
            ):
                setattr(self, k, v)
                logger.debug(f"Updated  {k=}, {v=}")
            else:
                logger.warning(f"Update ignored {k=}, {v=}")

    def _find_element(self):
        raise NotImplementedError

    @classmethod
    def from_instance(cls, obj):
        data = {k: getattr(obj, k) for k in obj._attrs}
        new_obj = cls(**data)

        return new_obj


class LazyElement(BaseLazy, WebElement):

    obj_list: Optional[List[WebElement]] = None
    _origin_class = WebElement

    _attrs = (
        "obj_list",
        "by",
        "value",
        "check_on_init",
        "time_out",
        "poll",
    )

    def __init__(
        self,
        by,
        value,
        check_on_init=True,
        time_out=None,
        poll=None,
        *args,
        **kwargs,
    ):
        self.by = by
        self.value = value
        self.check_on_init = check_on_init
        self.time_out = time_out
        self.poll = poll

    def _find_element(self, index=0):
        def f(_):
            logger.debug("Start wait ...")
            el_list = self.driver.find_elements(self.by, self.value)

            logger.debug("Found some elements ...")
            if len(el_list) <= index:
                logger.warning(f"Insufficient elements: {len(el_list)} <= {index}")
                return False

            logger.debug(f"Found elements, count({len(el_list)})")
            return el_list

        logger.debug(f"Find element start {index=}")
        try:
            if self.obj_list:
                logger.debug("Has some elements in cache")
                self.obj_list[index].text
        except StaleElementReferenceException:
            logger.warning("Interaction failed, retrying", exc_info=True)
            self.obj_list = None

        if self.obj_list is None:
            logger.info(f"Finding: {self}")
            obj_list = WebDriverWait(
                self.driver,
                self.time_out,
                self.poll,
            ).until(f)

            self.obj_list = obj_list
            logger.debug(f"Found:  elements count {len(self.obj_list)}")
        else:
            logger.debug("Get element by cache")

        obj = self.obj_list[index]
        logger.debug(f"Found:  {obj.tag_name} ,{obj.rect}")
        logger.debug("Find element done")
        return obj


class LazyElementList(LazyElement, list):
    _origin_class = list

    def __new__(cls, *args, **kwargs) -> List[WebElement]:
        return super().__new__(cls, *args, **kwargs)

    def __len__(self):
        self._find_element()
        return len(self.obj_list)

    def __getitem__(self, index):
        return self._find_element(index)

    def __iter__(self):
        for i in range(len(self)):
            yield self[i]


class LazyAlert(BaseLazy, Alert):

    _origin_class = Alert

    _attrs = (
        "check_on_init",
        "time_out",
        "poll",
    )

    def __init__(self, check_on_init=False, time_out=None, poll=None):
        self.check_on_init = check_on_init
        self.time_out = time_out
        self.poll = poll

    def _find_element(self):
        alert = WebDriverWait(
            self.driver,
            self.time_out,
            self.poll,
            ignored_exceptions=[NoAlertPresentException],
        ).until(lambda _: self.driver.switch_to.alert)

        return alert


class BasePage(metaclass=PageMeta):
    url = ""
    time_out = 5
    poll = 0.5
    _wait_interactive: Callable
    _check_elements: Callable

    # html = LazyElement(By.XPATH, "/html")

    alert = LazyAlert()

    def __init__(self, driver: WebDriver):
        logger.info(f"Page init start : {self.__class__.__name__}")
        self.driver = driver
        self.wait = WebDriverWait(driver, self.time_out, self.poll)
        self._check_elements()
        logger.info(f"Page init done: {self.__class__.__name__}")

    @classmethod
    def start(cls, driver, *args, **kwargs):
        url = cls.url.format(*args, **kwargs)
        logger.info(f"Goto start: {url=}")

        if not url:
            msg = "url is null, Browser has not changed"
            logger.warning(msg)
            warn(msg)
            return driver

        driver.get(url)
        logger.info("Goto done")
        return cls(driver)

    def _find_element(self, *args, **kwargs):

        logger.info(f"Page._find_element, {self=}, {args=}, {kwargs=}")
        return self.wait.until(
            lambda x: self.driver.find_element(
                *args,
                **kwargs,
            )
        )

    def click(self, ele: LazyElement, by_js=False):
        """
        点击指定元素
        :param ele: 元素
        :param by_js: 是否通过JS强制点击
        :return:
        """
        logger.info(f"Click start: {ele=}, {by_js=}")
        if by_js:
            self.driver.execute_script("arguments[0].click()", ele)
        else:
            self._wait_interactive(ele)
            ele.click()

        logger.info("Click done")

    def send_keys(
        self,
        ele: LazyElement,
        content="",
        clear=True,
        by_js=False,
    ):
        """
        在指定元素中输入内容
        :param ele: 输入框
        :param content: 待输入内容
        :param clear: 是否清空原有内容
        :param by_js: 是否通过JS强制输入
        :return:
        """
        logger.info(f"Send_keys start: {ele=}, {content=}, {clear=}, {by_js=}")
        if by_js:
            if clear:
                js = f"arguments[0].value='{content}'"
            else:
                js = f"arguments[0].value+='{content}'"

            self.driver.execute_script(js, ele)

        else:
            self._wait_interactive(ele)
            if clear:
                ele.clear()
                logger.debug("Clear origin content")
            if content:
                ele.send_keys(content)

        logger.info("Send_keys done")

    def upload(self, ele: LazyElement, file_path, drop=False):
        """
        在指定元素中上传文件
        :param ele: 元素
        :param file_path: 文件路径（相对路径或绝对路径）
        :param drop: 是否拖拽上传
        :return:
        """
        logger.info(f"Upload start: {ele=}, {file_path=}, {drop=}")
        self._wait_interactive(ele)

        path = Path(file_path)
        if not path.exists():
            logger.warning(f"File not exists: {path.absolute()}")
        if not path.is_file():
            logger.warning(f"File not is a file: {path.absolute()}")

        if drop:
            upload_by_drop(ele, path)
        else:
            ele.send_keys(str(path.absolute()))

        logger.info("Upload done")

    def wait_url_change(self):
        """
        等待页面跳转（url发生变化）
        :return:
        """
        url = self.driver.current_url
        logger.info(f"wait_url_change start: {url=}")
        self.wait.until(url_changes(url))

        logger.info(f"wait_url_change done: {url=}")

    def select(self, ele: LazyElement, value: str) -> Optional[Select]:
        """
        适用于原生select的下拉选择

        :param ele: 选择框
        :param value: 要选择的项
        :return: Select(ele)
        """

        logger.info(f"Select start：{ele=}, {value=}")
        if not value:
            logger.warning(f"Value is empty: {value=}")
            return None

        self._wait_interactive(ele)
        select = Select(ele)

        logger.info("Load option ...")
        option_list = ele.text
        logger.debug(f"{option_list=}")

        if str(value) not in option_list:
            logger.warning(f"The value({value}) is not in the options({option_list})")

        select.select_by_visible_text(value)

        logger.info("Select done")
        return select

    def chosen(self, ele: LazyElement, value: str):
        """
        适用于jquery-chosen的下拉选择

        :param ele: 选择框
        :param value: 要输入的值
        """

        logger.info(f"jQuery chosen start：{ele=}, {value=}")
        if not value:
            logger.warning("Value is empty")
            return

        self.click(ele)
        logger.info("Load option ...")
        option_list = ele.find_element(By.XPATH, "./div/ul").text
        logger.debug(f"{option_list=}")

        if str(value) not in option_list:
            logger.warning(f"The value({value}) is not in the options({option_list})")

        ele_option = self.wait.until(
            lambda x: ele.find_element(By.XPATH, f"./div/ul/li[text()='{value}']")
        )

        self.click(ele_option)
        logger.info("jQuery chosen done")


class AlertPage(BasePage):
    def ok(self, content=None):
        if content:
            self.alert.send_keys(content)

        self.alert.accept()

    def cancel(self):
        self.alert.dismiss()
